# messagingApp
End to end encrypted messaging web application 
using Flask (Python web development framework)
Socket.io for realtime socket package transfers 
and MySQL for storing user accounts 
The ultimate goal is to not allow packet capture software like WireShark to capture the network packets 
<br>
Look at requirements to make sure it runs correctly
